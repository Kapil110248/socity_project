'use client'

import { useAuthStore } from '@/lib/stores/auth-store'
import { useEmergencyStore } from '@/lib/stores/emergency-store'
import { useServiceStore } from '@/lib/stores/service-store'
import {
    QrCode,
    Wrench,
    Shield,
    History,
    ArrowRight,
    Clock,
    Bell,
    Smartphone,
    User,
    Settings,
    Phone,
    Video,
    TrendingUp
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'
import { motion } from 'framer-motion'

export function IndividualDashboard() {
    const { user } = useAuthStore()
    const { barcodes, logs: emergencyLogs } = useEmergencyStore()
    const { inquiries } = useServiceStore()

    const activeBarcodes = barcodes.filter(b => b.residentId === user?.id || b.residentName === user?.name)
    const recentInquiries = inquiries.filter(i => i.residentName === user?.name).slice(0, 3)
    const recentAlerts = emergencyLogs.filter(l => l.residentName === user?.name).slice(0, 3)

    return (
        <div className="space-y-8 pb-12">
            {/* Welcome Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <h1 className="text-4xl font-black text-gray-900 tracking-tight">
                        Hello, {user?.name.split(' ')[0]}!
                    </h1>
                    <p className="text-gray-500 mt-2 font-medium text-lg">
                        Welcome to your personal safety and services hub.
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <Link href="/dashboard/settings">
                        <Button variant="outline" className="rounded-2xl h-12 border-0 ring-1 ring-black/5 shadow-sm px-6 font-bold gap-2">
                            <Settings className="h-4 w-4" />
                            Settings
                        </Button>
                    </Link>
                </div>
            </div>

            {/* Core Stats / Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="p-8 border-0 shadow-2xl bg-gradient-to-br from-[#1e3a5f] to-[#2d4a6f] rounded-[40px] text-white relative overflow-hidden group">
                    <div className="relative z-10">
                        <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6 border border-white/20 backdrop-blur-md">
                            <QrCode className="h-6 w-6 text-teal-300" />
                        </div>
                        <h3 className="text-2xl font-bold mb-2">My QR Codes</h3>
                        <p className="text-white/60 text-sm mb-6 leading-relaxed">
                            {activeBarcodes.length} active emergency barcodes protecting your assets.
                        </p>
                        <Link href="/dashboard/qr-access">
                            <Button className="w-full bg-teal-500 hover:bg-teal-400 text-[#1e3a5f] font-black rounded-2xl h-14 tracking-tight">
                                MANAGE CODES
                            </Button>
                        </Link>
                    </div>
                </Card>

                <Card className="p-8 border-0 shadow-xl bg-white rounded-[40px] ring-1 ring-black/5 relative overflow-hidden group">
                    <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center mb-6">
                        <Wrench className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Book Service</h3>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                        Request pest control, plumbing, or electrical services instantly.
                    </p>
                    <Link href="/dashboard/services">
                        <Button variant="outline" className="w-full h-14 rounded-2xl font-black border-2 border-gray-100 hover:bg-gray-50 tracking-tight text-[#1e3a5f]">
                            EXPLORE SERVICES
                        </Button>
                    </Link>
                </Card>

                <Card className="p-8 border-0 shadow-xl bg-white rounded-[40px] ring-1 ring-black/5 relative overflow-hidden group">
                    <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center mb-6">
                        <Shield className="h-6 w-6 text-red-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Security Hub</h3>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                        Monitor scan logs and manage emergency contacts.
                    </p>
                    <Button variant="outline" className="w-full h-14 rounded-2xl font-black border-2 border-gray-100 hover:bg-gray-50 tracking-tight text-[#1e3a5f]">
                        VIEW LOGS
                    </Button>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Recent Emergency Alerts */}
                <Card className="border-0 shadow-xl bg-white rounded-[40px] ring-1 ring-black/5 overflow-hidden">
                    <CardHeader className="p-8 border-b border-gray-50 flex flex-row items-center justify-between">
                        <div>
                            <CardTitle className="text-xl font-black text-gray-900">Recent Emergency Alerts</CardTitle>
                            <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-1">Live Updates</p>
                        </div>
                        <Badge className="bg-red-50 text-red-700 border-0 rounded-full font-black px-3">{recentAlerts.length}</Badge>
                    </CardHeader>
                    <CardContent className="p-4">
                        <div className="space-y-2">
                            {recentAlerts.map((log) => (
                                <div key={log.id} className="p-6 rounded-3xl bg-gray-50 hover:bg-gray-100 transition-all group">
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center font-bold text-red-600 shadow-sm text-xl">
                                                {log.visitorName.charAt(0)}
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-900">{log.visitorName}</p>
                                                <div className="flex items-center gap-2 mt-0.5">
                                                    <Clock className="h-3 w-3 text-gray-400" />
                                                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
                                                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(log.timestamp).toLocaleDateString()}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        {log.isEmergency && (
                                            <Badge className="bg-red-100 text-red-700 border-0 rounded-full text-[10px] font-black px-2 shadow-none">URGENT</Badge>
                                        )}
                                    </div>
                                    <p className="mt-4 text-sm text-gray-500 italic font-medium">"{log.reason || 'No specific reason provided.'}"</p>
                                    <div className="mt-6 flex gap-3">
                                        <Button className="flex-1 h-12 bg-white hover:bg-gray-50 text-[#1e3a5f] font-bold rounded-2xl ring-1 ring-black/5 gap-2 border-0">
                                            <Phone className="h-4 w-4" /> CALL
                                        </Button>
                                        <Button className="flex-1 h-12 bg-white hover:bg-gray-50 text-[#1e3a5f] font-bold rounded-2xl ring-1 ring-black/5 gap-2 border-0">
                                            <Video className="h-4 w-4" /> VIDEO
                                        </Button>
                                    </div>
                                </div>
                            ))}
                            {recentAlerts.length === 0 && (
                                <div className="py-20 text-center">
                                    <Bell className="h-12 w-12 text-gray-100 mx-auto mb-4" />
                                    <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No Recent Alerts</p>
                                </div>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Recent Service Bookings */}
                <Card className="border-0 shadow-xl bg-white rounded-[40px] ring-1 ring-black/5 overflow-hidden">
                    <CardHeader className="p-8 border-b border-gray-50 flex flex-row items-center justify-between">
                        <div>
                            <CardTitle className="text-xl font-black text-gray-900">Recent Service Bookings</CardTitle>
                            <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-1">Status Tracking</p>
                        </div>
                        <Badge className="bg-blue-50 text-blue-700 border-0 rounded-full font-black px-3">{recentInquiries.length}</Badge>
                    </CardHeader>
                    <CardContent className="p-4">
                        <div className="space-y-2">
                            {recentInquiries.map((inquiry) => (
                                <div key={inquiry.id} className="p-6 rounded-3xl bg-gray-50 hover:bg-gray-100 transition-all">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center gap-4">
                                            <div className="p-3 bg-white rounded-2xl shadow-sm">
                                                <Wrench className="h-5 w-5 text-blue-600" />
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-900">{inquiry.serviceName}</p>
                                                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{inquiry.providerName}</p>
                                            </div>
                                        </div>
                                        <Badge className={`border-0 rounded-full text-[10px] font-black px-3 py-1 shadow-none uppercase ${inquiry.status === 'completed' ? 'bg-green-100 text-green-700' :
                                            inquiry.status === 'confirmed' ? 'bg-blue-100 text-blue-700' :
                                                'bg-yellow-100 text-yellow-700'
                                            }`}>
                                            {inquiry.status}
                                        </Badge>
                                    </div>
                                    <div className="flex items-center justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest pt-4 border-t border-gray-100">
                                        <div className="flex items-center gap-2">
                                            <Calendar className="h-3 w-3" />
                                            {inquiry.preferredDate || 'TBD'}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Clock className="h-3 w-3" />
                                            {inquiry.preferredTime || 'TBD'}
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {recentInquiries.length === 0 && (
                                <div className="py-20 text-center">
                                    <History className="h-12 w-12 text-gray-100 mx-auto mb-4" />
                                    <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No Recent Service Requests</p>
                                </div>
                            )}
                        </div>
                        {recentInquiries.length > 0 && (
                            <Link href="/dashboard/services">
                                <Button variant="ghost" className="w-full mt-4 h-12 rounded-2xl text-xs font-black uppercase tracking-widest text-gray-400 hover:text-gray-600">
                                    VIEW ALL SERVICE HISTORY <ArrowRight className="h-3 w-3 ml-2" />
                                </Button>
                            </Link>
                        )}
                    </CardContent>
                </Card>
            </div>

            {/* Premium App Promo */}
            <Card className="border-0 shadow-2xl bg-gradient-to-r from-teal-500 to-blue-600 rounded-[40px] p-10 text-white flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 blur-[100px] rounded-full -mr-32 -mt-32" />
                <div className="relative z-10 max-w-lg">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-white/20 rounded-xl">
                            <Smartphone className="h-6 w-6" />
                        </div>
                        <span className="font-black uppercase tracking-widest text-xs">Mobile Companion</span>
                    </div>
                    <h3 className="text-3xl font-black mb-4">Never miss an emergency alert.</h3>
                    <p className="text-white/80 font-medium leading-relaxed mb-8">
                        Get the IGATESECURITY app to receive instant push notifications, video calls, and real-time scan alerts on your phone.
                    </p>
                    <div className="flex flex-wrap gap-4">
                        <Button className="bg-white text-teal-600 hover:bg-gray-100 h-14 px-8 rounded-2xl font-black transition-all active:scale-[0.98]">
                            DOWNLOAD APP
                        </Button>
                        <Button variant="ghost" className="h-14 px-8 rounded-2xl font-black text-white hover:bg-white/10 ring-1 ring-white/20">
                            LEARN MORE
                        </Button>
                    </div>
                </div>
                <div className="relative z-10 hidden md:block">
                    <div className="w-48 h-48 bg-white/20 rounded-[40px] backdrop-blur-md border border-white/30 flex items-center justify-center p-8">
                        <QrCode className="w-full h-full text-white/50" />
                    </div>
                </div>
            </Card>
        </div>
    )
}

function Calendar({ className }: { className?: string }) {
    return (
        <svg
            className={className}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
        >
            <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
        </svg>
    )
}
